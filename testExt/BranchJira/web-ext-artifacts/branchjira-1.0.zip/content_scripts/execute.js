(function() {
  if (window.hasRun) {
    return;
  }
  window.hasRun = true;

  function doAction(action) {
    console.log(action);
    if(action==="Branch")
    {
      var sp = document.querySelectorAll('span[id^="type-val"]');
      console.log(sp.values);
    }
    if(action==="Commit-Message")
    {
      console.log("Yeet")
    }
  }

  function reset() {
    console.log("reset?");
  }

  browser.runtime.onMessage.addListener((message) => {
    if (message.command === "cmd") {
      doAction(message.action);
    } else if (message.command === "reset") {
      reset();
    }
  });

})();
