# BranchJira
Copies the right branch Name into your Clipboard